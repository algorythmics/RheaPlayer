oldies are some object used in previous art work
and now obsolete or to be fixed and integrated

Use example.pd to generate a patch like this for your work,
so these can be seen as ideas for different projects.

mfg
 winfried ritsch
