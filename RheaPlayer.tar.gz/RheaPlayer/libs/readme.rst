Place needed external libraries for Pd in here.

This could be the case if 
- they are not available on the system or local Pd installation,
- not wanting to use deken or its default directory,
- for development and debug of such a dependent library,
- personal decision.

A script is put in here to get the latest from repos for:

 acre - algorithmic composition realtime environment 

Note: Also deken can be used to download external libraries in here.

mfg
 winfried
