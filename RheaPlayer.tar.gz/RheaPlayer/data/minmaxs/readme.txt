Parameter storage which can change for each piano or even over time.

As a default one file with name default.txt is here, but an individual one for each piano can and should be overwritten with
own file an prefix of the rhea number: <parametersname>-<rheanumber>.txt
