Parameter storage which can change for each piano or even over time.

A template file is in here, but an individual one with the same name as in the pdpp lib/data can be located in here for overwrite. 
pde_piano_<rheanumber>_notemap.txt
